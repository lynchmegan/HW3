package com.example.hw3;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText entryField;
    private ListView listView;
    private ArrayList<String> items;
    private ArrayAdapter<String> arrayAdapter;
    private listviewjava adapter;
    private int index;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        entryField = (EditText) findViewById(R.id.entryField);
        listView = (ListView) findViewById(R.id.listView);

        ActionBar actionBar;
        actionBar = getSupportActionBar();
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#4A4159"));
        actionBar.setBackgroundDrawable(colorDrawable);

        items = new ArrayList<>();
        items.add("study");
        items.add("sleep");
        items.add("shop");

        adapter = new listviewjava(this,items);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                index = position;
                entryField.setText(items.get(position));


            }
        });

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add:

                items.add(entryField.getText().toString());
                adapter.notifyDataSetChanged();
                entryField.getText().clear();
                return true;

            case R.id.delete:

                items.remove(index);
                adapter.notifyDataSetChanged();
                entryField.getText().clear();

                return true;

            case R.id.update:

                    items.set(index, entryField.getText().toString());
                    adapter.notifyDataSetChanged();
                    entryField.getText().clear();
                return true;
            case R.id.save:

                return true;

            case R.id.close:
                finish();
            default:
                return super.onOptionsItemSelected(item);

        }
    }
}

